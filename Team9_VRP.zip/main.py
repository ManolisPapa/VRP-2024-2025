from Draft_Routing import *
from LocalSearch import *

m = Model()
m.BuildModel('Instance.txt')

solver = Draft_Routing_Solver(m)
solution = solver.solve()

localSolver = LocalSolver(m, 5)
solution = localSolver.LocalSolve(solution)
solver.sol = solution
solver.transport_solution_to_txt()

print(1)
